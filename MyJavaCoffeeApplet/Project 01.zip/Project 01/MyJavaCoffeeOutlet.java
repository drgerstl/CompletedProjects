/********************************************************************
 *
 * File:		MyJavaCoffeeOutlet.java
 *
 * Author: 		Dan Gerstl
 *
 * Date:		04/29/2018
 *
 * Purpose:		Project 1
 *
 * Description: Driver program for MyJavaCoffeeOutletGUI
 *
 * Comment:		NA
 *
 *********************************************************************/

 public class MyJavaCoffeeOutlet
 {
	 public static void main(String[] args)
	 {
		 MyJavaCoffeeOutletGUI driver = new MyJavaCoffeeOutletGUI(
			 							   "MyJava Coffee Outlet");
	 }

}